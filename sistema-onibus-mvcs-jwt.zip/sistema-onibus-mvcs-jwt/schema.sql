CREATE DATABASE IF NOT EXISTS viagens_db;
USE viagens_db;

-- Tabela de usuários (admin, etc.)
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  senha VARCHAR(255) NOT NULL,
  tipo ENUM('admin','usuario') DEFAULT 'usuario',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de clientes
CREATE TABLE clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(100),
  telefone VARCHAR(20),
  cidade VARCHAR(50),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de ônibus
CREATE TABLE onibus (
  id INT AUTO_INCREMENT PRIMARY KEY,
  modelo VARCHAR(100) NOT NULL,
  placa VARCHAR(10) NOT NULL,
  capacidade INT NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de viagens
CREATE TABLE viagens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  destino VARCHAR(100) NOT NULL,
  data_saida DATE NOT NULL,
  horario_saida TIME NOT NULL,
  id_onibus INT,
  id_cliente INT,
  FOREIGN KEY (id_onibus) REFERENCES onibus(id),
  FOREIGN KEY (id_cliente) REFERENCES clientes(id),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
ALTER TABLE usuarios 
CHANGE senha senha_hash VARCHAR(255) NOT NULL;
