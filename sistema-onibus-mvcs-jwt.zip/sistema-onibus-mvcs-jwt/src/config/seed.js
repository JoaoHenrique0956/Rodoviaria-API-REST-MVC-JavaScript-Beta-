import { query } from './db.js';
import bcrypt from 'bcryptjs';

export async function ensureDefaultAdmin() {
  const rows = await query('SELECT COUNT(*) as total FROM usuarios');
  if (rows[0].total === 0) {
    const email = 'admin@email.com';
    const senha = '12345';
    const hash = await bcrypt.hash(senha, 10);
    await query('INSERT INTO usuarios (email, senha_hash) VALUES (?, ?)', [email, hash]);
    console.log('> Usuário admin criado:', email, '(senha: 12345)');
  }
}
