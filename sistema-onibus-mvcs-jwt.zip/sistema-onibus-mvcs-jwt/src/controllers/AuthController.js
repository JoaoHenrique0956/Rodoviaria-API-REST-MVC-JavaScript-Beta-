import { query } from '../config/db.js'; import bcrypt from 'bcryptjs'; import jwt from 'jsonwebtoken';
export default class AuthController{
  loginView(req,res){ res.render('auth/login',{title:'Login'}); }
  async loginPost(req,res){
    const { email, senha } = req.body;
    const rows = await query('SELECT * FROM usuarios WHERE email=?',[email]);
    if(!rows.length) return res.render('auth/login',{title:'Login', error:'Usuário ou senha inválidos'});
    const ok = await bcrypt.compare(senha, rows[0].senha_hash);
    if(!ok) return res.render('auth/login',{title:'Login', error:'Usuário ou senha inválidos'});
    const token = jwt.sign({ uid: rows[0].id, email: rows[0].email }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES || '1d' });
    res.cookie('token', token, { httpOnly: true, sameSite: 'lax' });
    res.redirect('/menu');
  }
  logout(req,res){ res.clearCookie('token'); res.redirect('/login'); }
}
