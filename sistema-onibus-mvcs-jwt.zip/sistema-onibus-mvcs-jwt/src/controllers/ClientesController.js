import ClienteService from '../services/ClienteService.js';
const service = new ClienteService();
export default class ClientesController{
  async list(req,res,next){ try{
    if(req.query.delete && Number.isInteger(Number(req.query.delete))){ await service.remove(Number(req.query.delete)); return res.redirect('/clientes'); }
    const clientes = await service.list();
    res.render('clientes/index',{ title:'Clientes - Pesquisa', clientes });
  }catch(e){next(e)}}
  formNew(req,res){ res.render('clientes/form',{ title:'Novo Cliente', cliente:null }); }
  async create(req,res,next){ try{ await service.create(req.body); res.redirect('/clientes'); }catch(e){next(e)}}
  async formEdit(req,res,next){ try{ const cliente = await service.get(req.params.id); if(!cliente) return res.redirect('/clientes'); res.render('clientes/form',{ title:'Editar Cliente', cliente }); }catch(e){next(e)}}
  async update(req,res,next){ try{ await service.update(req.params.id, req.body); res.redirect('/clientes'); }catch(e){next(e)}}
}
