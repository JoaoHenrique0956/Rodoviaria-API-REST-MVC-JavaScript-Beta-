export default class DashboardController{
  menu(req,res){ res.render('dashboard/menu',{ title:'Sistema de Ônibus - Painel Principal' }); }
}
