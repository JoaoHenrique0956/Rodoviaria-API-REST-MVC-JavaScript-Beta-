import OnibusService from '../services/OnibusService.js'; import multer from 'multer';
const service = new OnibusService();
export const upload = multer({ storage: multer.memoryStorage() });
export default class OnibusController{
  async list(req,res,next){ try{
    if(req.query.delete && Number.isInteger(Number(req.query.delete))){ await service.remove(Number(req.query.delete)); return res.redirect('/onibus'); }
    const onibus = await service.list();
    res.render('onibus/index',{ title:'Ônibus - Pesquisa', onibus });
  }catch(e){next(e)}}
  formNew(req,res){ res.render('onibus/form',{ title:'Novo Ônibus', item:null }); }
  async create(req,res,next){ try{ await service.create(req.body); res.redirect('/onibus'); }catch(e){next(e)}}
  async formEdit(req,res,next){ try{ const item = await service.get(req.params.id); if(!item) return res.redirect('/onibus'); res.render('onibus/form',{ title:'Editar Ônibus', item }); }catch(e){next(e)}}
  async update(req,res,next){ try{ await service.update(req.params.id, req.body); res.redirect('/onibus'); }catch(e){next(e)}}
  async importJson(req,res,next){ try{
    const file = req.file;
    if(!file) return res.redirect('/onibus');
    const content = JSON.parse(file.buffer.toString('utf-8'));
    const arr = Array.isArray(content) ? content : content.onibus || [];
    await service.importMany(arr);
    res.redirect('/onibus');
  }catch(e){next(e)}}
}
