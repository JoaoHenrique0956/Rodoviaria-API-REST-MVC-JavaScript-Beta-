import ViagemService from '../services/ViagemService.js';
const service = new ViagemService();
export default class ViagensController{
  async list(req,res,next){ try{
    if(req.query.delete && Number.isInteger(Number(req.query.delete))){ await service.remove(Number(req.query.delete)); return res.redirect('/viagens'); }
    const viagens = await service.list();
    res.render('viagens/index',{ title:'Viagens - Pesquisa', viagens });
  }catch(e){next(e)}}
  formNew(req,res){ res.render('viagens/form',{ title:'Nova Viagem', item:null }); }
  async create(req,res,next){ try{ await service.create(req.body); res.redirect('/viagens'); }catch(e){next(e)}}
  async formEdit(req,res,next){ try{ const item = await service.get(req.params.id); if(!item) return res.redirect('/viagens'); res.render('viagens/form',{ title:'Editar Viagem', item }); }catch(e){next(e)}}
  async update(req,res,next){ try{ await service.update(req.params.id, req.body); res.redirect('/viagens'); }catch(e){next(e)}}
}
