import { query } from '../config/db.js';
export default class ClienteDAO {
  async all(){ return await query('SELECT * FROM clientes ORDER BY id DESC'); }
  async find(id){ return await query('SELECT * FROM clientes WHERE id=?',[id]); }
  async create(c){ const r = await query('INSERT INTO clientes (nome,email,telefone) VALUES (?,?,?)',[c.nome,c.email,c.telefone]); return r.insertId; }
  async update(id,c){ await query('UPDATE clientes SET nome=COALESCE(?,nome), email=COALESCE(?,email), telefone=COALESCE(?,telefone) WHERE id=?',[c.nome??null,c.email??null,c.telefone??null,id]); }
  async remove(id){ await query('DELETE FROM clientes WHERE id=?',[id]); }
}
