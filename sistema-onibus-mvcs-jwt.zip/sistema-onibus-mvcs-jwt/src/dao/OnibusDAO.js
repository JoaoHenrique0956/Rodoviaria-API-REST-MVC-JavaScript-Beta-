import { query } from '../config/db.js';
export default class OnibusDAO {
  async all(){ return await query('SELECT * FROM onibus ORDER BY id DESC'); }
  async find(id){ return await query('SELECT * FROM onibus WHERE id=?',[id]); }
  async create(o){ const r = await query('INSERT INTO onibus (placa,modelo,capacidade) VALUES (?,?,?)',[o.placa,o.modelo,o.capacidade]); return r.insertId; }
  async update(id,o){ await query('UPDATE onibus SET placa=COALESCE(?,placa), modelo=COALESCE(?,modelo), capacidade=COALESCE(?,capacidade) WHERE id=?',[o.placa??null,o.modelo??null,o.capacidade??null,id]); }
  async remove(id){ await query('DELETE FROM onibus WHERE id=?',[id]); }
}
