import { query } from '../config/db.js';
export default class ViagemDAO {
  async all(){ return await query(`SELECT v.*, o.placa, o.modelo, o.capacidade FROM viagens v JOIN onibus o ON o.id=v.onibus_id ORDER BY v.id DESC`); }
  async find(id){ return await query(`SELECT v.*, o.placa, o.modelo, o.capacidade FROM viagens v JOIN onibus o ON o.id=v.onibus_id WHERE v.id=?`,[id]); }
  async create(v){ const r = await query('INSERT INTO viagens (onibus_id,origem,destino,data_partida,data_chegada,preco) VALUES (?,?,?,?,?,?)',[v.onibus_id,v.origem,v.destino,v.data_partida,v.data_chegada,v.preco]); return r.insertId; }
  async update(id,v){ await query('UPDATE viagens SET onibus_id=COALESCE(?,onibus_id), origem=COALESCE(?,origem), destino=COALESCE(?,destino), data_partida=COALESCE(?,data_partida), data_chegada=COALESCE(?,data_chegada), preco=COALESCE(?,preco) WHERE id=?',[v.onibus_id??null,v.origem??null,v.destino??null,v.data_partida??null,v.data_chegada??null,v.preco??null,id]); }
  async remove(id){ await query('DELETE FROM viagens WHERE id=?',[id]); }
}
