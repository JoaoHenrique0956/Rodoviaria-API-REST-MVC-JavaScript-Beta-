export default class Cliente {
  #id; #nome; #email; #telefone;
  get id(){return this.#id} set id(v){this.#id=Number(v)}
  get nome(){return this.#nome} set nome(v){ if(!v||v.trim().length<2) throw new Error('nome inválido'); this.#nome=v.trim() }
  get email(){return this.#email} set email(v){ if(!v||!v.includes('@')) throw new Error('email inválido'); this.#email=v.trim() }
  get telefone(){return this.#telefone} set telefone(v){ this.#telefone=v||null }
}
