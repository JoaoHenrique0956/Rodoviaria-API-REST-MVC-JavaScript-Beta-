export default class Onibus {
  #id; #placa; #modelo; #capacidade;
  get id(){return this.#id} set id(v){this.#id=Number(v)}
  get placa(){return this.#placa} set placa(v){ if(!v||v.length<5) throw new Error('placa inválida'); this.#placa=v.toUpperCase() }
  get modelo(){return this.#modelo} set modelo(v){ if(!v||v.length<2) throw new Error('modelo inválido'); this.#modelo=v }
  get capacidade(){return this.#capacidade} set capacidade(v){ const n=Number(v); if(!Number.isInteger(n)||n<=0) throw new Error('capacidade inválida'); this.#capacidade=n }
}
