export default class Viagem {
  #id; #onibus_id; #origem; #destino; #data_partida; #data_chegada; #preco;
  get id(){return this.#id} set id(v){this.#id=Number(v)}
  get onibus_id(){return this.#onibus_id} set onibus_id(v){const n=Number(v); if(!Number.isInteger(n)||n<=0) throw new Error('onibus_id inválido'); this.#onibus_id=n}
  get origem(){return this.#origem} set origem(v){ if(!v) throw new Error('origem obrigatória'); this.#origem=v }
  get destino(){return this.#destino} set destino(v){ if(!v) throw new Error('destino obrigatório'); this.#destino=v }
  get data_partida(){return this.#data_partida} set data_partida(v){ this.#data_partida=v }
  get data_chegada(){return this.#data_chegada} set data_chegada(v){ this.#data_chegada=v||null }
  get preco(){return this.#preco} set preco(v){ this.#preco=Number(v||0) }
}
