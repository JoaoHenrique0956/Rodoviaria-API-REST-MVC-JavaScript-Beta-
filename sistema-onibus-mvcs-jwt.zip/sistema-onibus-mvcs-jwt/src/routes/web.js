import { Router } from 'express';
import AuthController from '../controllers/AuthController.js';
import DashboardController from '../controllers/DashboardController.js';
import ClientesController from '../controllers/ClientesController.js';
import OnibusController, { upload } from '../controllers/OnibusController.js';
import ViagensController from '../controllers/ViagensController.js';
import { requireAuth } from '../middlewares/auth.js';

const router = Router();
const auth = new AuthController();
const dash = new DashboardController();
const clientes = new ClientesController();
const onibus = new OnibusController();
const viagens = new ViagensController();

router.get('/', (req,res)=> res.redirect('/menu'));

// auth
router.get('/login', (req,res)=> auth.loginView(req,res));
router.post('/login', (req,res)=> auth.loginPost(req,res));
router.post('/logout', (req,res)=> auth.logout(req,res));

// protected
router.get('/menu', requireAuth, (req,res)=> dash.menu(req,res));

// clientes
router.get('/clientes', requireAuth, (req,res,n)=> clientes.list(req,res,n));
router.get('/clientes/novo', requireAuth, (req,res)=> clientes.formNew(req,res));
router.post('/clientes/novo', requireAuth, (req,res,n)=> clientes.create(req,res,n));
router.get('/clientes/editar/:id', requireAuth, (req,res,n)=> clientes.formEdit(req,res,n));
router.post('/clientes/editar/:id', requireAuth, (req,res,n)=> clientes.update(req,res,n));

// onibus
router.get('/onibus', requireAuth, (req,res,n)=> onibus.list(req,res,n));
router.get('/onibus/novo', requireAuth, (req,res)=> onibus.formNew(req,res));
router.post('/onibus/novo', requireAuth, (req,res,n)=> onibus.create(req,res,n));
router.get('/onibus/editar/:id', requireAuth, (req,res,n)=> onibus.formEdit(req,res,n));
router.post('/onibus/editar/:id', requireAuth, (req,res,n)=> onibus.update(req,res,n));
router.post('/onibus/import', requireAuth, upload.single('arquivo'), (req,res,n)=> onibus.importJson(req,res,n));

// viagens
router.get('/viagens', requireAuth, (req,res,n)=> viagens.list(req,res,n));
router.get('/viagens/novo', requireAuth, (req,res)=> viagens.formNew(req,res));
router.post('/viagens/novo', requireAuth, (req,res,n)=> viagens.create(req,res,n));
router.get('/viagens/editar/:id', requireAuth, (req,res,n)=> viagens.formEdit(req,res,n));
router.post('/viagens/editar/:id', requireAuth, (req,res,n)=> viagens.update(req,res,n));

export default router;
