import Cliente from '../models/Cliente.js'; import ClienteDAO from '../dao/ClienteDAO.js';
export default class ClienteService{
  #dao = new ClienteDAO();
  async list(){ return await this.#dao.all(); }
  async get(id){ const r = await this.#dao.find(id); return r[0]||null; }
  async create(body){ const c = new Cliente(); c.nome=body.nome; c.email=body.email; c.telefone=body.telefone; return await this.#dao.create(c); }
  async update(id,body){ const c = new Cliente(); if(body.nome!==undefined) c.nome=body.nome; if(body.email!==undefined) c.email=body.email; if(body.telefone!==undefined) c.telefone=body.telefone; await this.#dao.update(id, body); }
  async remove(id){ await this.#dao.remove(id); }
}
