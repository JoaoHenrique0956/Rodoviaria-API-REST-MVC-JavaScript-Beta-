import Onibus from '../models/Onibus.js'; import OnibusDAO from '../dao/OnibusDAO.js';
export default class OnibusService{
  #dao = new OnibusDAO();
  async list(){ return await this.#dao.all(); }
  async get(id){ const r = await this.#dao.find(id); return r[0]||null; }
  async create(body){ const o = new Onibus(); o.placa=body.placa; o.modelo=body.modelo; o.capacidade=body.capacidade; return await this.#dao.create(o); }
  async update(id,body){ await this.#dao.update(id, body); }
  async remove(id){ await this.#dao.remove(id); }
  async importMany(arr){ // arr: [{placa,modelo,capacidade},...]
    for(const item of arr){ try { await this.create(item);} catch(e){ /* skip invalid */ } }
  }
}
