import Viagem from '../models/Viagem.js'; import ViagemDAO from '../dao/ViagemDAO.js';
export default class ViagemService{
  #dao = new ViagemDAO();
  async list(){ return await this.#dao.all(); }
  async get(id){ const r = await this.#dao.find(id); return r[0]||null; }
  async create(body){ const v = new Viagem(); v.onibus_id=body.onibus_id; v.origem=body.origem; v.destino=body.destino; v.data_partida=body.data_partida; v.data_chegada=body.data_chegada; v.preco=body.preco; return await this.#dao.create(v); }
  async update(id,body){ await this.#dao.update(id, body); }
  async remove(id){ await this.#dao.remove(id); }
}
